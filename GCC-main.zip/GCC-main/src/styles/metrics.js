export default {
  padding: 20,
  margin: 16,
  radius: 10,
};