export const demoUsers = [
  {
    name: "Vishal Kattera",
    email: "vishal.glansa@gmail.com",
    role: "customer",
  },
  {
    name: "Harish Glansa",
    email: "harish@glansa.com",
    role: "technician",
  },
  {
    name: "Nagaraju Glansa",
    email: "nagaraju1.glansa@gmail.com",
    role: "technician",
  },
  {
    name: "Sourav",
    email: "sourav.glansa@gmail.com",
    role: "customer",
  },
  {
    name: "Naveen",
    email: "naveennyain.glansa@gmail.com",
    role: "customer",
  },
];
